import React, { useState, useEffect } from 'react';
import { Menu, X, Heart, ShoppingBag, LogOut, Plus, Edit2, Trash2, Search, ChevronDown, Camera, Phone, MapPin } from 'lucide-react';

const OWNER_CODE = 'PRTRENDZ-OWNER-2026';

// ======================== STYLES ========================
const styles = {
  container: {
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    backgroundColor: '#0b0b0b',
    color: '#f4f1ea',
    minHeight: '100vh',
  },
  navbar: {
    backgroundColor: 'rgba(16,16,16,.94)',
    borderBottom: '1px solid rgba(212,175,55,.18)',
    boxShadow: '0 8px 30px rgba(0,0,0,0.25)',
    position: 'sticky',
    top: 0,
    zIndex: 100,
  },
  navContent: {
    maxWidth: '1400px',
    margin: '0 auto',
    padding: '1rem 2rem',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logo: {
    fontSize: '1.8rem',
    fontWeight: '700',
    background: 'linear-gradient(135deg, #d4af37 0%, #b8860b 100%)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
  },
  navLinks: {
    display: 'flex',
    gap: '2rem',
    alignItems: 'center',
    '@media (max-width: 768px)': {
      display: 'none',
    }
  },
  navLink: {
    cursor: 'pointer',
    fontSize: '0.95rem',
    color: '#555',
    transition: 'color 0.3s',
    fontWeight: '500',
  },
  button: {
    padding: '0.75rem 1.5rem',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '0.95rem',
    fontWeight: '600',
    transition: 'all 0.3s ease',
  },
  primaryButton: {
    backgroundColor: '#d4af37',
    color: '#000',
    padding: '0.75rem 1.5rem',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontWeight: '600',
    transition: 'all 0.3s ease',
  },
  secondaryButton: {
    backgroundColor: 'transparent',
    color: '#333',
    border: '2px solid #d4af37',
    padding: '0.75rem 1.5rem',
    borderRadius: '8px',
    cursor: 'pointer',
    fontWeight: '600',
  },
  hero: {
    background: 'radial-gradient(circle at 50% 20%, #282214 0%, #111 42%, #090909 100%)',
    padding: '4rem 2rem',
    textAlign: 'center',
    maxWidth: '1400px',
    margin: '0 auto',
  },
  heroTitle: {
    fontSize: '3rem',
    fontWeight: '700',
    color: '#fff',
    marginBottom: '1rem',
    letterSpacing: '-1px',
  },
  heroSubtitle: {
    fontSize: '1.3rem',
    color: '#bdbdbd',
    marginBottom: '2rem',
    fontWeight: '300',
  },
  section: {
    maxWidth: '1400px',
    margin: '0 auto',
    padding: '3rem 2rem',
  },
  sectionTitle: {
    fontSize: '2.2rem',
    fontWeight: '700',
    marginBottom: '2rem',
    color: '#1a1a1a',
    textAlign: 'center',
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
    gap: '2rem',
    '@media (max-width: 768px)': {
      gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
      gap: '1.5rem',
    }
  },
  productCard: {
    background: 'linear-gradient(145deg,#171717,#0d0d0d)',
    border: '1px solid rgba(212,175,55,.16)',
    borderRadius: '18px',
    overflow: 'hidden',
    boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
    transition: 'all 0.3s ease',
    cursor: 'pointer',
  },
  productImage: {
    width: '100%',
    height: '280px',
    background: 'linear-gradient(135deg,#24201a,#111)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '3rem',
    position: 'relative',
    overflow: 'hidden',
  },
  productBadge: {
    position: 'absolute',
    top: '1rem',
    right: '1rem',
    backgroundColor: '#d4af37',
    color: '#000',
    padding: '0.5rem 1rem',
    borderRadius: '20px',
    fontSize: '0.75rem',
    fontWeight: '700',
  },
  productInfo: {
    padding: '1.5rem',
  },
  productCategory: {
    fontSize: '0.75rem',
    color: '#999',
    textTransform: 'uppercase',
    fontWeight: '600',
    marginBottom: '0.5rem',
  },
  productName: {
    fontSize: '1.1rem',
    fontWeight: '600',
    marginBottom: '0.8rem',
    color: '#1a1a1a',
  },
  priceSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.8rem',
    marginBottom: '1.2rem',
  },
  price: {
    fontSize: '1.3rem',
    fontWeight: '700',
    color: '#d4af37',
  },
  originalPrice: {
    fontSize: '0.95rem',
    color: '#999',
    textDecoration: 'line-through',
  },
  discount: {
    backgroundColor: '#ffe4e1',
    color: '#c41e3a',
    padding: '0.4rem 0.8rem',
    borderRadius: '4px',
    fontSize: '0.8rem',
    fontWeight: '700',
  },
  buyButton: {
    width: '100%',
    backgroundColor: '#1a1a1a',
    color: '#fff',
    border: 'none',
    padding: '0.8rem',
    borderRadius: '8px',
    cursor: 'pointer',
    fontWeight: '600',
    fontSize: '0.95rem',
    transition: 'all 0.3s ease',
  },
  modal: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
  },
  modalContent: {
    background: 'linear-gradient(145deg,#191919,#0e0e0e)',
    border: '1px solid rgba(212,175,55,.18)',
    borderRadius: '18px',
    padding: '2rem',
    maxWidth: '500px',
    maxHeight: '90vh',
    overflowY: 'auto',
    width: '95%',
  },
  formGroup: {
    marginBottom: '1.5rem',
  },
  label: {
    display: 'block',
    fontWeight: '600',
    marginBottom: '0.5rem',
    color: '#333',
  },
  input: {
    width: '100%',
    padding: '0.8rem',
    border: '2px solid #e0ddd9',
    borderRadius: '8px',
    fontSize: '0.95rem',
    fontFamily: 'inherit',
    boxSizing: 'border-box',
    transition: 'border-color 0.3s',
  },
  textarea: {
    width: '100%',
    padding: '0.8rem',
    border: '2px solid #e0ddd9',
    borderRadius: '8px',
    fontSize: '0.95rem',
    fontFamily: 'inherit',
    boxSizing: 'border-box',
    minHeight: '100px',
    resize: 'vertical',
  },
  select: {
    width: '100%',
    padding: '0.8rem',
    border: '2px solid #e0ddd9',
    borderRadius: '8px',
    fontSize: '0.95rem',
    fontFamily: 'inherit',
    cursor: 'pointer',
  },
  dashboardContainer: {
    maxWidth: '1400px',
    margin: '0 auto',
    padding: '2rem',
  },
  dashboardHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '2rem',
    borderBottom: '2px solid #e0ddd9',
    paddingBottom: '1.5rem',
  },
  dashboardTitle: {
    fontSize: '2rem',
    fontWeight: '700',
    color: '#1a1a1a',
  },
  footer: {
    backgroundColor: '#1a1a1a',
    color: '#fff',
    padding: '3rem 2rem',
    marginTop: '4rem',
  },
  footerContent: {
    maxWidth: '1400px',
    margin: '0 auto',
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '2rem',
  },
  ownerBtn: {
    position: 'fixed',
    bottom: '2rem',
    right: '2rem',
    width: '50px',
    height: '50px',
    borderRadius: '50%',
    backgroundColor: '#d4af37',
    color: '#000',
    border: 'none',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
    zIndex: 99,
    fontWeight: '600',
    fontSize: '0.75rem',
    transition: 'all 0.3s ease',
  }
};

// ======================== COMPONENTS ========================

// Product Card Component
const ProductCard = ({ product, onBuyNow, onWishlist, isWishlisted }) => {
  const discount = product.originalPrice ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) : 0;
  
  return (
    <div style={styles.productCard} onMouseEnter={(e) => e.currentTarget.style.boxShadow = '0 8px 20px rgba(0,0,0,0.12)'} onMouseLeave={(e) => e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.08)'}>
      <div style={styles.productImage}>
        {product.image ? <img src={product.image} alt={product.name} style={{width:'100%',height:'100%',objectFit:'cover'}} /> : <span>{product.emoji || '👗'}</span>}
        {product.badge && <div style={styles.productBadge}>{product.badge}</div>}
      </div>
      <div style={styles.productInfo}>
        <div style={styles.productCategory}>{product.category}</div>
        <div style={styles.productName}>{product.name}</div>
        <div style={styles.priceSection}>
          <div style={styles.price}>₹{product.price}</div>
          {product.originalPrice && (
            <>
              <div style={styles.originalPrice}>₹{product.originalPrice}</div>
              <div style={styles.discount}>{discount}% OFF</div>
            </>
          )}
        </div>
        <button style={styles.buyButton} onClick={() => onBuyNow(product)}>
          BUY NOW
        </button>
      </div>
    </div>
  );
};

// Login Modal
const LoginModal = ({ onClose, onLogin }) => {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');

  const handleLogin = () => {
    if (code === OWNER_CODE) {
      onLogin();
    } else {
      setError('Invalid access code');
      setCode('');
    }
  };

  return (
    <div style={styles.modal} onClick={onClose}>
      <div style={styles.modalContent} onClick={(e) => e.stopPropagation()}>
        <h2 style={{ marginBottom: '1.5rem', color: '#1a1a1a' }}>Owner Access</h2>
        <div style={styles.formGroup}>
          <label style={styles.label}>Access Code</label>
          <input 
            style={styles.input}
            type="password" 
            placeholder="Enter access code"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
          />
        </div>
        {error && <div style={{ color: '#c41e3a', marginBottom: '1rem', fontWeight: '600' }}>{error}</div>}
        <button type="button" style={{...styles.primaryButton, width: '100%'}} onClick={handleLogin}>
          Enter Dashboard
        </button>
      </div>
    </div>
  );
};

// Add/Edit Product Modal
const ProductFormModal = ({ onClose, onSave, product = null, isEdit = false }) => {
  const [formData, setFormData] = useState(product || {
    name: '',
    category: 'Jewellery',
    price: '',
    originalPrice: '',
    description: '',
    meeshoLink: '',
    image: '',
    badge: '',
    emoji: '👗',
    available: true,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSave = () => {
    if (!formData.name || !formData.price || !formData.meeshoLink) {
      alert('Please fill in all required fields');
      return;
    }
    onSave(formData);
  };

  return (
    <div style={styles.modal} onClick={onClose}>
      <div style={styles.modalContent} onClick={(e) => e.stopPropagation()}>
        <h2 style={{ marginBottom: '1.5rem' }}>{isEdit ? 'Edit Product' : 'Add New Product'}</h2>
        
        <div style={styles.formGroup}>
          <label style={styles.label}>Product Name *</label>
          <input 
            style={styles.input}
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="e.g., Elegant Gold Necklace"
          />
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Category</label>
          <select style={styles.select} name="category" value={formData.category} onChange={handleChange}>
            <option>Jewellery</option>
            <option>Clothing</option>
            <option>Gift Hampers</option>
            <option>Beauty</option>
            <option>Accessories</option>
          </select>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Price (₹) *</label>
            <input 
              style={styles.input}
              name="price"
              type="number"
              value={formData.price}
              onChange={handleChange}
              placeholder="999"
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Original Price (₹)</label>
            <input 
              style={styles.input}
              name="originalPrice"
              type="number"
              value={formData.originalPrice}
              onChange={handleChange}
              placeholder="1299"
            />
          </div>
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Meesho Product Link *</label>
          <input 
            style={styles.input}
            name="meeshoLink"
            value={formData.meeshoLink}
            onChange={handleChange}
            placeholder="https://meesho.com/..."
          />
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Product Image</label>
          <input
            style={{...styles.input, padding: '0.6rem'}}
            type="file"
            accept="image/*"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              if (file.size > 3 * 1024 * 1024) { alert('Please choose an image smaller than 3MB.'); return; }
              const reader = new FileReader();
              reader.onload = () => setFormData(prev => ({ ...prev, image: reader.result }));
              reader.readAsDataURL(file);
            }}
          />
          {formData.image ? (
            <img src={formData.image} alt="Product preview" style={{width:'100%', height:180, objectFit:'cover', borderRadius:12, marginTop:10}} />
          ) : (
            <div style={{marginTop:10, padding:'1rem', border:'1px dashed #b89b4a', borderRadius:12, color:'#777', textAlign:'center'}}>Choose a product photo to preview it here</div>
          )}
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Description</label>
          <textarea 
            style={styles.textarea}
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="Product description..."
          />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Badge</label>
            <select style={styles.select} name="badge" value={formData.badge} onChange={handleChange}>
              <option value="">None</option>
              <option value="NEW">NEW</option>
              <option value="BESTSELLER">BESTSELLER</option>
              <option value="SALE">SALE</option>
            </select>
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Emoji</label>
            <input 
              style={styles.input}
              name="emoji"
              maxLength="2"
              value={formData.emoji}
              onChange={handleChange}
              placeholder="👗"
            />
          </div>
        </div>

        <div style={{ display: 'flex', gap: '1rem' }}>
          <button type="button" style={{...styles.primaryButton, flex: 1}} onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleSave(); }}>
            {isEdit ? 'Update Product' : 'Add Product'}
          </button>
          <button type="button" style={{...styles.secondaryButton, flex: 1}} onClick={onClose}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

// Main App Component
export default function PRTrendz() {
  const [showIntro, setShowIntro] = useState(() => sessionStorage.getItem('prtrendz_intro_seen') !== '1');
  const [currentPage, setCurrentPage] = useState('home');
  const [products, setProducts] = useState([]);
  const [isOwnerLoggedIn, setIsOwnerLoggedIn] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [wishlist, setWishlist] = useState([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');
  const [sortBy, setSortBy] = useState('newest');

  // Load products from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('prtrendz_products');
    if (saved) {
      setProducts(JSON.parse(saved));
    } else {
      initializeDemoProducts();
    }
  }, []);

  // Initialize demo products
  const initializeDemoProducts = () => {
    const demoProducts = [
      {
        id: Date.now() + 1,
        name: 'Elegant Anti-Tarnish Earrings',
        category: 'Jewellery',
        price: 599,
        originalPrice: 999,
        description: 'Premium anti-tarnish golden earrings with pearl accents',
        meeshoLink: 'https://meesho.com/',
        badge: 'BESTSELLER',
        emoji: '💎',
        available: true,
      },
      {
        id: Date.now() + 2,
        name: 'Emerald Statement Necklace',
        category: 'Jewellery',
        price: 1299,
        originalPrice: 1899,
        description: 'Stunning emerald pendant with 24k gold plating',
        meeshoLink: 'https://meesho.com/',
        badge: 'NEW',
        emoji: '✨',
        available: true,
      },
      {
        id: Date.now() + 3,
        name: 'Gold Minimalist Bracelet',
        category: 'Accessories',
        price: 449,
        originalPrice: 799,
        description: 'Delicate gold-plated minimalist bracelet',
        meeshoLink: 'https://meesho.com/',
        badge: '',
        emoji: '💫',
        available: true,
      },
      {
        id: Date.now() + 4,
        name: 'Premium Gifting Hamper',
        category: 'Gift Hampers',
        price: 1999,
        originalPrice: 2999,
        description: 'Luxurious gift hamper with jewellery, chocolates & skincare',
        meeshoLink: 'https://meesho.com/',
        badge: 'SALE',
        emoji: '🎁',
        available: true,
      },
      {
        id: Date.now() + 5,
        name: 'Women\'s Ethnic Set',
        category: 'Clothing',
        price: 899,
        originalPrice: 1499,
        description: 'Beautiful ethnic Indian wear set',
        meeshoLink: 'https://meesho.com/',
        badge: '',
        emoji: '👗',
        available: true,
      },
      {
        id: Date.now() + 6,
        name: 'Pearl Jewellery Set',
        category: 'Jewellery',
        price: 1599,
        originalPrice: 2299,
        description: 'Complete jewellery set with earrings, necklace & bracelet',
        meeshoLink: 'https://meesho.com/',
        badge: 'BESTSELLER',
        emoji: '👑',
        available: true,
      },
    ];
    setProducts(demoProducts);
    localStorage.setItem('prtrendz_products', JSON.stringify(demoProducts));
  };

  // Save products to localStorage
  const saveProducts = (updatedProducts) => {
    setProducts(updatedProducts);
    localStorage.setItem('prtrendz_products', JSON.stringify(updatedProducts));
  };

  // Handle add/edit product
  const handleSaveProduct = (formData) => {
    if (editingProduct) {
      const updated = products.map(p => p.id === editingProduct.id ? { ...formData, id: p.id } : p);
      saveProducts(updated);
      setEditingProduct(null);
    } else {
      const newProduct = { ...formData, id: Date.now() };
      saveProducts([...products, newProduct]);
    }
    setShowProductModal(false);
  };

  // Handle delete product
  const handleDeleteProduct = (id) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      saveProducts(products.filter(p => p.id !== id));
    }
  };

  // Handle buy now
  const handleBuyNow = (product) => {
    if (product.meeshoLink) {
      window.open(product.meeshoLink, '_blank');
    }
  };

  // Filter and sort products
  const getFilteredProducts = () => {
    let filtered = products;
    
    if (searchTerm) {
      filtered = filtered.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
    }
    
    if (filterCategory !== 'All') {
      filtered = filtered.filter(p => p.category === filterCategory);
    }
    
    if (sortBy === 'price-low') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-high') {
      filtered.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'newest') {
      filtered.sort((a, b) => b.id - a.id);
    }
    
    return filtered;
  };

  // ======================== PAGES ========================

  // HOME PAGE
  const HomePage = () => (
    <div>
      {/* Hero Section */}
      <div style={styles.hero}>
        <h1 style={styles.heroTitle}>Elegance That Speaks For You</h1>
        <p style={styles.heroSubtitle}>Premium fashion, jewellery and gifting — curated by PR TRENDZ.</p>
        <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
          <button style={styles.primaryButton} onClick={() => setCurrentPage('shop')}>
            SHOP NOW
          </button>
          <button style={styles.secondaryButton} onClick={() => setCurrentPage('shop')}>
            EXPLORE COLLECTION
          </button>
        </div>
      </div>

      {/* Featured Section */}
      <div style={styles.section}>
        <h2 style={styles.sectionTitle}>✨ Featured Collections</h2>
        <div style={styles.grid}>
          {products.slice(0, 3).map(product => (
            <ProductCard 
              key={product.id} 
              product={product} 
              onBuyNow={handleBuyNow}
            />
          ))}
        </div>
      </div>

      {/* Tagline Section */}
      <div style={{
        backgroundColor: '#1a1a1a',
        color: '#fff',
        textAlign: 'center',
        padding: '3rem 2rem',
        margin: '2rem 0',
      }}>
        <p style={{ fontSize: '1.8rem', fontWeight: '700', margin: 0 }}>Affordable Price | Premium Quality</p>
      </div>
    </div>
  );

  // SHOP PAGE
  const ShopPage = () => {
    const filteredProducts = getFilteredProducts();
    
    return (
      <div style={styles.section}>
        <h1 style={styles.sectionTitle}>Our Collections</h1>
        
        {/* Filters */}
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '1rem',
          marginBottom: '2rem',
          backgroundColor: '#fff',
          padding: '1.5rem',
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
        }}>
          <div>
            <label style={{...styles.label, marginBottom: '0.5rem'}}>Search</label>
            <input 
              style={styles.input}
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div>
            <label style={{...styles.label, marginBottom: '0.5rem'}}>Category</label>
            <select style={styles.select} value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)}>
              <option>All</option>
              <option>Jewellery</option>
              <option>Clothing</option>
              <option>Gift Hampers</option>
              <option>Beauty</option>
              <option>Accessories</option>
            </select>
          </div>
          <div>
            <label style={{...styles.label, marginBottom: '0.5rem'}}>Sort By</label>
            <select style={styles.select} value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
              <option value="newest">Newest</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Products Grid */}
        {filteredProducts.length > 0 ? (
          <div style={styles.grid}>
            {filteredProducts.map(product => (
              <ProductCard 
                key={product.id} 
                product={product} 
                onBuyNow={handleBuyNow}
              />
            ))}
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '3rem' }}>
            <p style={{ fontSize: '1.1rem', color: '#999' }}>No products found</p>
          </div>
        )}
      </div>
    );
  };

  // ABOUT PAGE
  const AboutPage = () => (
    <div style={styles.section}>
      <h1 style={styles.sectionTitle}>About PR TRENDZ</h1>
      <div style={{
        maxWidth: '800px',
        margin: '0 auto',
        backgroundColor: '#fff',
        padding: '2rem',
        borderRadius: '12px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
        lineHeight: '1.8',
      }}>
        <p style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>
          <strong>PR TRENDZ</strong> is a growing fashion and lifestyle brand bringing together elegant jewellery, stylish clothing, thoughtful gifts and everyday beauty essentials at affordable prices.
        </p>
        <p style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>
          Based in Bulandshahr, Uttar Pradesh, we are committed to delivering premium quality products that elevate your everyday style.
        </p>
        <p style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>
          Our mission: <strong>Affordable Price | Premium Quality</strong>
        </p>
        <p style={{ fontSize: '1.1rem' }}>
          Every product is carefully curated to ensure you get the best value without compromising on quality, design, or elegance.
        </p>
      </div>
    </div>
  );

  // CONTACT PAGE
  const ContactPage = () => (
    <div style={styles.section}>
      <h1 style={styles.sectionTitle}>Get In Touch</h1>
      <div style={{
        maxWidth: '600px',
        margin: '0 auto',
        backgroundColor: '#fff',
        padding: '2rem',
        borderRadius: '12px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
          <MapPin style={{ color: '#d4af37' }} size={24} />
          <div>
            <h3 style={{ margin: 0, marginBottom: '0.3rem' }}>Location</h3>
            <p style={{ margin: 0, color: '#666' }}>Bulandshahr, Uttar Pradesh, India</p>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
          <Camera style={{ color: '#d4af37' }} size={24} />
          <div>
            <h3 style={{ margin: 0, marginBottom: '0.3rem' }}>Instagram</h3>
            <a href="https://instagram.com/pr_trendz" target="_blank" rel="noopener noreferrer" style={{ color: '#d4af37', textDecoration: 'none', fontWeight: '600' }}>
              @pr_trendz
            </a>
          </div>
        </div>
        <button style={{...styles.primaryButton, width: '100%'}} onClick={() => window.open('https://instagram.com/pr_trendz', '_blank')}>
          FOLLOW ON INSTAGRAM
        </button>
      </div>
    </div>
  );

  // OWNER DASHBOARD
  const OwnerDashboard = () => (
    <div style={styles.dashboardContainer}>
      <div style={styles.dashboardHeader}>
        <h1 style={styles.dashboardTitle}>PR TRENDZ Owner Panel</h1>
        <button style={{...styles.button, backgroundColor: '#c41e3a', color: '#fff'}} onClick={() => setIsOwnerLoggedIn(false)}>
          <LogOut size={18} style={{ marginRight: '0.5rem' }} />
          Logout
        </button>
      </div>

      {/* Overview Stats */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '1.5rem',
        marginBottom: '2rem',
      }}>
        <div style={{ background: 'linear-gradient(145deg,#191919,#0d0d0d)', padding: '1.5rem', border: '1px solid rgba(212,175,55,.15)', borderRadius: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}>
          <div style={{ fontSize: '0.9rem', color: '#999', fontWeight: '600', marginBottom: '0.5rem' }}>Total Products</div>
          <div style={{ fontSize: '2rem', fontWeight: '700', color: '#d4af37' }}>{products.length}</div>
        </div>
        <div style={{ background: 'linear-gradient(145deg,#191919,#0d0d0d)', padding: '1.5rem', border: '1px solid rgba(212,175,55,.15)', borderRadius: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}>
          <div style={{ fontSize: '0.9rem', color: '#999', fontWeight: '600', marginBottom: '0.5rem' }}>Jewellery</div>
          <div style={{ fontSize: '2rem', fontWeight: '700', color: '#d4af37' }}>{products.filter(p => p.category === 'Jewellery').length}</div>
        </div>
        <div style={{ background: 'linear-gradient(145deg,#191919,#0d0d0d)', padding: '1.5rem', border: '1px solid rgba(212,175,55,.15)', borderRadius: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}>
          <div style={{ fontSize: '0.9rem', color: '#999', fontWeight: '600', marginBottom: '0.5rem' }}>Clothing</div>
          <div style={{ fontSize: '2rem', fontWeight: '700', color: '#d4af37' }}>{products.filter(p => p.category === 'Clothing').length}</div>
        </div>
        <div style={{ background: 'linear-gradient(145deg,#191919,#0d0d0d)', padding: '1.5rem', border: '1px solid rgba(212,175,55,.15)', borderRadius: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}>
          <div style={{ fontSize: '0.9rem', color: '#999', fontWeight: '600', marginBottom: '0.5rem' }}>Gift Hampers</div>
          <div style={{ fontSize: '2rem', fontWeight: '700', color: '#d4af37' }}>{products.filter(p => p.category === 'Gift Hampers').length}</div>
        </div>
      </div>

      {/* Product Management */}
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: '1.5rem', fontWeight: '700', margin: 0 }}>Product Management</h2>
          <button type="button" style={{...styles.primaryButton, position:'relative', zIndex:2}} onClick={(e) => {
            e.preventDefault(); e.stopPropagation();
            setEditingProduct(null);
            setShowProductModal(true);
          }}>
            <Plus size={18} style={{ marginRight: '0.5rem' }} />
            Add Product
          </button>
        </div>

        {/* Products Table */}
        <div style={{ 
          backgroundColor: '#fff', 
          borderRadius: '12px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
          overflowX: 'auto'
        }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #e0ddd9', backgroundColor: '#faf8f6' }}>
                <th style={{ padding: '1rem', textAlign: 'left', fontWeight: '600' }}>Product</th>
                <th style={{ padding: '1rem', textAlign: 'left', fontWeight: '600' }}>Category</th>
                <th style={{ padding: '1rem', textAlign: 'left', fontWeight: '600' }}>Price</th>
                <th style={{ padding: '1rem', textAlign: 'left', fontWeight: '600' }}>Meesho Link</th>
                <th style={{ padding: '1rem', textAlign: 'center', fontWeight: '600' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map(product => (
                <tr key={product.id} style={{ borderBottom: '1px solid #e0ddd9' }}>
                  <td style={{ padding: '1rem' }}>
                    <div style={{ fontWeight: '600' }}>{product.name}</div>
                    <div style={{ fontSize: '0.85rem', color: '#999' }}>{product.emoji}</div>
                  </td>
                  <td style={{ padding: '1rem' }}>{product.category}</td>
                  <td style={{ padding: '1rem', fontWeight: '600' }}>₹{product.price}</td>
                  <td style={{ padding: '1rem' }}>
                    <a href={product.meeshoLink} target="_blank" rel="noopener noreferrer" style={{ color: '#d4af37', textDecoration: 'none', fontSize: '0.9rem' }}>
                      View
                    </a>
                  </td>
                  <td style={{ padding: '1rem', textAlign: 'center' }}>
                    <button 
                      style={{...styles.button, backgroundColor: '#d4af37', color: '#000', marginRight: '0.5rem', padding: '0.5rem 1rem' }}
                      onClick={() => {
                        setEditingProduct(product);
                        setShowProductModal(true);
                      }}
                    >
                      <Edit2 size={16} />
                    </button>
                    <button 
                      style={{...styles.button, backgroundColor: '#c41e3a', color: '#fff', padding: '0.5rem 1rem' }}
                      onClick={() => handleDeleteProduct(product.id)}
                    >
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  // ======================== MAIN RENDER ========================

  const enterSite = () => {
    sessionStorage.setItem('prtrendz_intro_seen', '1');
    setShowIntro(false);
  };

  const pages = ['home', 'shop', 'about', 'contact'];
  const pageIndex = pages.indexOf(currentPage);
  const goPrev = () => setCurrentPage(pages[(pageIndex - 1 + pages.length) % pages.length]);
  const goNext = () => setCurrentPage(pages[(pageIndex + 1) % pages.length]);

  if (showIntro) {
    return (
      <div style={{minHeight:'100vh', background:'radial-gradient(circle at 50% 35%, #2a2416 0%, #0a0a0a 42%, #050505 100%)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', padding:24, position:'relative', overflow:'hidden'}}>
        <div style={{position:'absolute', inset:0, background:'linear-gradient(120deg, transparent 0%, rgba(212,175,55,.08) 50%, transparent 100%)'}} />
        <div style={{position:'relative', zIndex:1, textAlign:'center', maxWidth:850}}>
          <div style={{letterSpacing:'0.45em', color:'#d4af37', fontSize:12, fontWeight:700, marginBottom:24}}>PR TRENDZ • EST. 2026</div>
          <h1 style={{fontFamily:'Georgia, serif', fontSize:'clamp(3.5rem, 10vw, 7rem)', lineHeight:.95, margin:'0 0 24px', letterSpacing:'-0.04em'}}>PR TRENDZ</h1>
          <p style={{fontSize:'clamp(1rem, 2vw, 1.35rem)', color:'#c9c9c9', margin:'0 auto 38px', maxWidth:620}}>Discover curated fashion, jewellery and lifestyle pieces designed to make every look feel extraordinary.</p>
          <button onClick={enterSite} style={{background:'linear-gradient(135deg,#e5c45b,#b8860b)', color:'#080808', border:'none', borderRadius:999, padding:'16px 38px', fontSize:15, fontWeight:800, letterSpacing:'.12em', cursor:'pointer', boxShadow:'0 10px 40px rgba(212,175,55,.22)'}}>ENTER WEBSITE</button>
          <div style={{marginTop:18, color:'#777', fontSize:12}}>Premium quality • Affordable price</div>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      {isOwnerLoggedIn ? (
        <OwnerDashboard />
      ) : (
        <>
          {/* NAVBAR */}
          <nav style={styles.navbar}>
            <div style={styles.navContent}>
              <div style={styles.logo} onClick={() => setCurrentPage('home')}>PR TRENDZ</div>
              
              <div style={styles.navLinks}>
                <div style={styles.navLink} onClick={() => setCurrentPage('home')}>Home</div>
                <div style={styles.navLink} onClick={() => setCurrentPage('shop')}>Shop</div>
                <div style={styles.navLink} onClick={() => setCurrentPage('shop')}>Jewellery</div>
                <div style={styles.navLink} onClick={() => setCurrentPage('shop')}>Clothing</div>
                <div style={styles.navLink} onClick={() => setCurrentPage('about')}>About</div>
                <div style={styles.navLink} onClick={() => setCurrentPage('contact')}>Contact</div>
              </div>

              <button style={{display: 'none'}} onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </nav>

          {/* PAGE CONTENT */}
          {currentPage === 'home' && <HomePage />}
          {currentPage === 'shop' && <ShopPage />}
          {currentPage === 'about' && <AboutPage />}
          {currentPage === 'contact' && <ContactPage />}

          {/* FOOTER */}
          <footer style={styles.footer}>
            <div style={styles.footerContent}>
              <div>
                <h3 style={{ margin: '0 0 1rem 0' }}>PR TRENDZ</h3>
                <p style={{ color: '#ccc', margin: 0 }}>Affordable Price | Premium Quality</p>
              </div>
              <div>
                <h4 style={{ margin: '0 0 1rem 0' }}>Quick Links</h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', color: '#ccc' }}>
                  <div style={{ cursor: 'pointer' }} onClick={() => setCurrentPage('home')}>Home</div>
                  <div style={{ cursor: 'pointer' }} onClick={() => setCurrentPage('shop')}>Shop</div>
                  <div style={{ cursor: 'pointer' }} onClick={() => setCurrentPage('about')}>About</div>
                  <div style={{ cursor: 'pointer' }} onClick={() => setCurrentPage('contact')}>Contact</div>
                </div>
              </div>
              <div>
                <h4 style={{ margin: '0 0 1rem 0' }}>Follow Us</h4>
                <button style={{...styles.primaryButton}} onClick={() => window.open('https://instagram.com/pr_trendz', '_blank')}>
                  <Camera size={18} /> Instagram
                </button>
              </div>
            </div>
            <div style={{ borderTop: '1px solid #333', marginTop: '2rem', paddingTop: '2rem', textAlign: 'center', color: '#999' }}>
              <p>© 2026 PR TRENDZ. All Rights Reserved.</p>
            </div>
          </footer>

          {/* OWNER ACCESS BUTTON */}
          <button 
            style={styles.ownerBtn}
            onClick={() => setShowLoginModal(true)}
            title="Owner Access"
          >
            👤
          </button>

          {/* MODALS */}
          {showLoginModal && <LoginModal onClose={() => setShowLoginModal(false)} onLogin={() => { setShowLoginModal(false); setIsOwnerLoggedIn(true); }} />}
          {showProductModal && <ProductFormModal onClose={() => setShowProductModal(false)} onSave={handleSaveProduct} product={editingProduct} isEdit={!!editingProduct} />}

          <div style={{position:'fixed', left:'50%', bottom:18, transform:'translateX(-50%)', zIndex:90, display:'flex', gap:10, padding:'7px 9px', borderRadius:999, background:'rgba(10,10,10,.88)', border:'1px solid rgba(212,175,55,.3)', backdropFilter:'blur(12px)', boxShadow:'0 8px 30px rgba(0,0,0,.35)'}}>
            <button aria-label="Previous page" onClick={goPrev} style={{width:42,height:42,borderRadius:'50%',border:'1px solid #444',background:'#161616',color:'#fff',fontSize:24,cursor:'pointer'}}>‹</button>
            <div style={{minWidth:82,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,color:'#d4af37',letterSpacing:'.12em',textTransform:'uppercase'}}>{currentPage}</div>
            <button aria-label="Next page" onClick={goNext} style={{width:42,height:42,borderRadius:'50%',border:'1px solid #444',background:'#161616',color:'#fff',fontSize:24,cursor:'pointer'}}>›</button>
          </div>
        </>
      )}
    </div>
  );
}
